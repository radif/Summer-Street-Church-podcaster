FTP (opens in /public_html directory... if you need to be further back than that, I can change it):
Host name: ftp.summerstreetchurch.org
User name: radif@summerstreetchurch.org
Password: SSC4TROTTERS

Cpanel for MySQL & PHP:
URL: www.summerstreetchurch.org/cpanel
username: summerst
password: 8kqpd1Cw36-k


DB: summerst_caststats
table: downloading_stats
username: summerst_podcast
password: 8kqpd1C


	NSArray *episodes=[FTPHandler episodes];
	NSLog(@"episodes:\n%@",episodes);


example: http://summerstreetchurch.org/podcasting/podcaster.php?url=http://summerstreetchurch.org/podcasting/cover.jpg



<?xml version="1.0" encoding="UTF-8"?>

<rss xmlns:itunes="http://www.itunes.com/dtds/podcast-1.0.dtd" version="2.0">
<channel>
<title>Summer Street Church Podcasting</title>
<link>http://summerstreetchurch.org/</link>
<language>en-us</language>
<copyright>Summer Street Church, Nantucket, MA</copyright>
<itunes:subtitle>Sunday Services</itunes:subtitle>
<itunes:author>Pastor Richard Leland</itunes:author>
<itunes:summary>Weekly Podcasting of Sunday Services From Summer Street Church, Nantucket, MA</itunes:summary>
<description>Weekly Podcasting of Sunday Services From Summer Street Church, Nantucket, MA</description>
<itunes:owner>
<itunes:name>Summer Street Church, Nantucket, MA</itunes:name>
<itunes:email>carolyn@summerstreetchurch.org</itunes:email>
</itunes:owner>
<itunes:image href="http://summerstreetchurch.org/podcasting/cover.jpg" />
<itunes:category text="Religion &amp; Spirituality">
<itunes:category text="Christianity" />
</itunes:category>
<geo:lat>41.276758</geo:lat>
<geo:long>-70.09089</geo:long>

$posts

</channel>

</rss>



//---------posts

<item>
<title>$title</title>
<itunes:author>Summer Street Church, Nantucket, MA</itunes:author>
<itunes:subtitle>Summer Street Church Podcasting</itunes:subtitle>
<itunes:summary>$desc</itunes:summary>
<enclosure url="http://summerstreetchurch.org/podcasting/podcaster.php?url=http://summerstreetchurch.org/podcasting/episodes/$file" length="0" type="audio/mpeg"  />
<pubDate>$date</pubDate>
<itunes:keywords>Summer,Street,Church,Nantucket,Evangelical,Christians,baptist,baptism,brant,point,Rich,Leland,Richard,Leland,4,Trotters,ln,summer,st,traders,ln,protestant,religion,christianity,preaching,preach,Jesus,Christ,Bible,Gospel,Service,Christian,music,New,Testam</itunes:keywords>
</item>

<?php
# stats
# (c)Radif Sharafullin
$timePeriod=$_GET["period"];
$episodeName=$_GET["episode"];
if(!$timePeriod){
	 die('No Input provided for Summer Street Church Podcaster (c)Radif Sharafullin');
}
$downloads = array();
$link = mysql_connect('localhost', 'summerst_podcast', '8kqpd1C');
if (!$link) {
    die('Could not connect!!!: ' . mysql_error());
}
mysql_select_db("summerst_caststats");


if($timePeriod==0){
	$query = "SELECT file, datetime, ip FROM downloading_stats";
	
	if($episodeName){	
		$query="$query WHERE file=$episodeName";
	}
	
}else{
	$offsetDate  = mktime(0, 0, 0, date("m")  , date("d")-$timePerod, date("Y"));
	$mysqldate = date( 'Y-m-d H:i:s',$offsetDate );
	$query = "SELECT file, datetime, ip FROM downloading_stats WHERE datetime >= $mysqldate";
	if($episodeName){	
		$query="$query AND file=$episodeName";
	}
}

$result=mysql_query($query);
if (!$result) {
    $message  = 'Invalid query: ' . mysql_error() . "\n";
    $message .= 'Whole query: ' . $query;
	mysql_close($link);
	mysql_free_result($result);
    die($message);
}



while ($row = mysql_fetch_assoc($result)) {
   # echo $row['file'];
   # echo $row['datetime'];
   # echo $row['ip'];

	$entry = array(
	    'file' 		=> $row['file'],
	    'datetime'  => $row['datetime'],
	    'ip'   	    => $row['ip']);

	array_push($downloads, $entry);
}


mysql_close($link);
mysql_free_result($result);

echo ArrayToXML::toXml($downloads,'downloads',null);

class ArrayToXML
{
	/**
	 * The main function for converting to an XML document.
	 * Pass in a multi dimensional array and this recrusively loops through and builds up an XML document.
	 *
	 * @param array $data
	 * @param string $rootNodeName - what you want the root node to be - defaultsto data.
	 * @param SimpleXMLElement $xml - should only be used recursively
	 * @return string XML
	 */
	public static function toXml($data, $rootNodeName = 'data', $xml=null)
	{
		// turn off compatibility mode as simple xml throws a wobbly if you don't.
		if (ini_get('zend.ze1_compatibility_mode') == 1)
		{
			ini_set ('zend.ze1_compatibility_mode', 0);
		}

		if ($xml == null)
		{
			$xml = simplexml_load_string("<?xml version='1.0' encoding='utf-8'?><$rootNodeName />");
		}

		// loop through the data passed in.
		foreach($data as $key => $value)
		{
			// no numeric keys in our xml please!
			if (is_numeric($key))
			{
				// make string key...
				$key = "entry". (string) $key;
			}

			// replace anything not alpha numeric
			$key = preg_replace('/[^a-z]/i', '', $key);

			// if there is another array found recrusively call this function
			if (is_array($value))
			{
				$node = $xml->addChild($key);
				// recrusive call.
				ArrayToXML::toXml($value, $rootNodeName, $node);
			}
			else 
			{
				// add single node.
                                $value = htmlentities($value);
				$xml->addChild($key,$value);
			}

		}
		// pass back as string. or simple xml object if you want!
		return $xml->asXML();
	}
}

?>

<?php
$url=$_GET["url"];
if(!$url){
	 die('No Input provided for Summer Street Church Podcaster (c)Radif Sharafullin');
}
ob_start();
$link = mysql_connect('localhost', 'summerst_podcast', '8kqpd1C');
if (!$link) {
    die('Could not connect!!!: ' . mysql_error());
}
mysql_select_db("summerst_caststats");
#echo 'Connected successfully';

date_default_timezone_set('EDT');
$mysqldate = date( 'Y-m-d H:i:s' );
$ip = getenv("REMOTE_ADDR"); 
$query = "INSERT INTO downloading_stats  VALUES ('','$url','$mysqldate','$ip')";
mysql_query($query);

mysql_close($link);

header("Location: $url");
ob_flush();
?>
